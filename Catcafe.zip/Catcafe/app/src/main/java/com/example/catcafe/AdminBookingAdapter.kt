package com.example.catcafe

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class AdminBookingAdapter(
    private var bookingList: List<Booking>,
    private val onUpdateStatus: (Booking, String) -> Unit,
    private val onDeleteBooking: (Booking) -> Unit
) : RecyclerView.Adapter<AdminBookingAdapter.AdminBookingViewHolder>() {

    // ✅ TAMBAH: FCM Server Key — pergi Firebase Console → Project Settings → Cloud Messaging → copy "Server key"
    private val FCM_SERVER_KEY = "YOUR_FCM_SERVER_KEY_HERE"
    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    class AdminBookingViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvBookingId: TextView = itemView.findViewById(R.id.tvAdminBookingId)
        val tvUserEmail: TextView = itemView.findViewById(R.id.tvAdminUserEmail)
        val tvDetails: TextView = itemView.findViewById(R.id.tvAdminDetails)
        val tvStatus: TextView = itemView.findViewById(R.id.tvAdminStatus)
        val btnAction: Button = itemView.findViewById(R.id.btnCancelBooking)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdminBookingViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_admin_booking, parent, false)
        return AdminBookingViewHolder(view)
    }

    override fun onBindViewHolder(holder: AdminBookingViewHolder, position: Int) {
        val booking = bookingList[position]

        holder.tvBookingId.text = "ID: #${booking.bookingId.take(6)}"
        holder.tvUserEmail.text = "User: ${booking.userName}"
        holder.tvDetails.text = "${booking.date} | ${booking.timeSlot} | ${booking.guests} Guests"
        holder.tvStatus.text = booking.status

        when (booking.status) {
            "Confirmed"  -> holder.tvStatus.setTextColor(Color.parseColor("#4CAF50"))
            "Checked In" -> holder.tvStatus.setTextColor(Color.parseColor("#2196F3"))
            "Completed"  -> holder.tvStatus.setTextColor(Color.parseColor("#9C27B0"))
            "Cancelled"  -> holder.tvStatus.setTextColor(Color.parseColor("#F44336"))
        }

        holder.btnAction.setOnClickListener { view ->
            val popup = PopupMenu(view.context, view)
            popup.menu.add("Confirmed")
            popup.menu.add("Checked In")
            popup.menu.add("Completed")
            popup.menu.add("Cancelled")
            popup.menu.add("Permanently Delete")

            popup.setOnMenuItemClickListener { item ->
                when (item.title.toString()) {
                    "Permanently Delete" -> {
                        onDeleteBooking(booking)
                    }
                    // ✅ TAMBAH: Hantar FCM notification ikut status yang admin pilih
                    "Confirmed" -> {
                        onUpdateStatus(booking, "Confirmed")
                        sendNotificationToUser(
                            userId = booking.userId,
                            title = "✅ Booking Confirmed!",
                            body = "Your visit on ${booking.date} at ${booking.timeSlot} is confirmed. See you soon! 🐱"
                        )
                    }
                    "Cancelled" -> {
                        onUpdateStatus(booking, "Cancelled")
                        sendNotificationToUser(
                            userId = booking.userId,
                            title = "❌ Booking Cancelled",
                            body = "Your booking on ${booking.date} at ${booking.timeSlot} has been cancelled."
                        )
                    }
                    "Completed" -> {
                        onUpdateStatus(booking, "Completed")
                        sendNotificationToUser(
                            userId = booking.userId,
                            title = "🐾 Thanks for visiting!",
                            body = "Hope you enjoyed your visit on ${booking.date}. Please leave us a review!"
                        )
                    }
                    "Checked In" -> {
                        onUpdateStatus(booking, "Checked In")
                        sendNotificationToUser(
                            userId = booking.userId,
                            title = "🐱 Welcome to Cat Cafe!",
                            body = "Your check-in on ${booking.date} at ${booking.timeSlot} is recorded. Enjoy!"
                        )
                    }
                }
                true
            }
            popup.show()
        }
    }

    override fun getItemCount() = bookingList.size

    fun updateList(newList: List<Booking>) {
        bookingList = newList
        notifyDataSetChanged()
    }

    // ✅ TAMBAH: Step 1 — Baca FCM token user dari Firebase
    private fun sendNotificationToUser(userId: String, title: String, body: String) {
        FirebaseDatabase.getInstance(DB_URL)
            .getReference("Users").child(userId).child("fcmToken")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val token = snapshot.getValue(String::class.java) ?: return
                    sendFcmRequest(token, title, body)
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    // ✅ TAMBAH: Step 2 — Hantar notification ke FCM API
    // Mesti dalam Thread sebab network call tak boleh kat main thread
    private fun sendFcmRequest(token: String, title: String, body: String) {
        Thread {
            try {
                val url = URL("https://fcm.googleapis.com/fcm/send")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Authorization", "key=$FCM_SERVER_KEY")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true

                val payload = JSONObject().apply {
                    put("to", token)
                    put("notification", JSONObject().apply {
                        put("title", title)
                        put("body", body)
                        put("sound", "default")
                    })
                    put("priority", "high")
                }

                val writer = OutputStreamWriter(conn.outputStream)
                writer.write(payload.toString())
                writer.flush()
                writer.close()
                conn.responseCode
                conn.disconnect()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }
}