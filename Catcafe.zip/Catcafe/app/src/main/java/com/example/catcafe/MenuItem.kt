package com.example.catcafe

data class MenuItem(
    val itemId: String = "",
    val name: String = "",
    val price: Double = 0.0,
    val imageUrl: String = "",
    val category: String = "" // "Food" atau "Drinks"
) {
    // Constructor kosong untuk Firebase
    constructor() : this("", "", 0.0, "", "")
}