package com.example.catcafe

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    private lateinit var emailInputLayout: TextInputLayout
    private lateinit var passwordInputLayout: TextInputLayout
    private lateinit var editTextEmail: TextInputEditText
    private lateinit var editTextPassword: TextInputEditText
    private lateinit var buttonLogin: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var textViewError: TextView
    private lateinit var ivLoginHeader: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)

        auth = Firebase.auth
        initViews()
        loadHeaderImage()
        checkCurrentUser()
        setupClickListeners()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finishAffinity()
            }
        })
    }

    private fun initViews() {
        emailInputLayout = findViewById(R.id.emailInputLayout)
        passwordInputLayout = findViewById(R.id.passwordInputLayout)
        editTextEmail = findViewById(R.id.editTextEmail)
        editTextPassword = findViewById(R.id.editTextPassword)
        buttonLogin = findViewById(R.id.buttonLogin)
        progressBar = findViewById(R.id.progressBar)
        textViewError = findViewById(R.id.textViewError)
        ivLoginHeader = findViewById(R.id.ivLoginHeader)
    }

    private fun loadHeaderImage() {
        val shopImageUrl = "https://tse3.mm.bing.net/th/id/OIP.PU__x39JOLuKWygm6zJtagAAAA?pid=Api&h=220&P=0"
        ivLoginHeader.load(shopImageUrl) {
            crossfade(true)
            placeholder(R.drawable.ic_launcher_background)
        }
    }

    private fun checkCurrentUser() {
        val user = auth.currentUser
        if (user != null) {
            fetchUserRoleAndNavigate(user.uid)
        }
    }

    private fun setupClickListeners() {
        buttonLogin.setOnClickListener { attemptLogin() }
        
        findViewById<TextView>(R.id.textViewRegister).setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        findViewById<TextView>(R.id.textViewForgotPassword).setOnClickListener {
            val email = editTextEmail.text.toString().trim()
            if (TextUtils.isEmpty(email)) {
                Toast.makeText(this, getString(R.string.enter_email_reset), Toast.LENGTH_SHORT).show()
            } else {
                auth.sendPasswordResetEmail(email).addOnSuccessListener {
                    Toast.makeText(this, getString(R.string.reset_link_sent), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun attemptLogin() {
        val email = editTextEmail.text.toString().trim()
        val password = editTextPassword.text.toString().trim()

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            showError("Please enter email and password")
            return
        }
        
        showLoading(true)
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    fetchUserRoleAndNavigate(auth.currentUser?.uid ?: "")
                } else {
                    showLoading(false)
                    showError(task.exception?.message ?: getString(R.string.login_failed))
                }
            }
    }

    private fun fetchUserRoleAndNavigate(uid: String) {
        showLoading(true)
        FirebaseDatabase.getInstance(DB_URL).getReference("Users").child(uid)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    showLoading(false)
                    val role = snapshot.child("role").getValue(String::class.java) ?: "Customer"
                    
                    val intent = if (role == "Admin") {
                        Intent(this@LoginActivity, AdminActivity::class.java)
                    } else {
                        Intent(this@LoginActivity, HomeActivity::class.java)
                    }
                    startActivity(intent)
                    finish()
                }

                override fun onCancelled(error: DatabaseError) {
                    showLoading(false)
                    showError("Auth Error: ${error.message}")
                }
            })
    }

    private fun showError(message: String) {
        textViewError.text = message
        textViewError.visibility = View.VISIBLE
    }

    private fun showLoading(loading: Boolean) {
        progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        buttonLogin.isEnabled = !loading
        buttonLogin.alpha = if (loading) 0.5f else 1.0f
    }
}