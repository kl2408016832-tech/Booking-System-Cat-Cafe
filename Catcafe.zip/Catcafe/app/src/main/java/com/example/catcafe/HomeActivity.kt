package com.example.catcafe

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import coil.load
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*

class HomeActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase

    private lateinit var textViewWelcome: TextView
    private lateinit var tvAverageRating: TextView
    private lateinit var tvOperatingStatus: TextView
    private lateinit var tvVisitStats: TextView
    private lateinit var tvTodayAvailability: TextView
    private lateinit var tvAnnouncementText: TextView
    private lateinit var cardAnnouncement: CardView
    private lateinit var cardAvailabilityPreview: CardView
    private lateinit var ivHeaderBackground: ImageView
    private lateinit var ivLogo: ImageView
    private lateinit var cardUpcomingBooking: CardView
    private lateinit var tvUpcomingBookingInfo: TextView

    private lateinit var swipeRefreshHome: SwipeRefreshLayout
    private lateinit var fabBookNow: FloatingActionButton

    private lateinit var rvHomeCats: RecyclerView
    private val homeCatList = mutableListOf<Cat>()
    private lateinit var homeCatAdapter: HomeCatAdapter

    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"
    private val MAX_CAPACITY_PER_SLOT = 30

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        auth = FirebaseAuth.getInstance()

        if (auth.currentUser == null) {
            redirectToLogin()
            return
        }

        setContentView(R.layout.activity_home)
        database = FirebaseDatabase.getInstance(DB_URL)

        initViews()
        setupClickListeners()
        loadAllData()
    }

    private fun redirectToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun initViews() {
        textViewWelcome = findViewById(R.id.textViewWelcome)
        tvAverageRating = findViewById(R.id.tvAverageRating)
        tvOperatingStatus = findViewById(R.id.tvOperatingStatus)
        tvVisitStats = findViewById(R.id.tvVisitStats)
        tvTodayAvailability = findViewById(R.id.tvTodayAvailability)
        tvAnnouncementText = findViewById(R.id.tvAnnouncementText)
        cardAnnouncement = findViewById(R.id.cardAnnouncement)
        cardAvailabilityPreview = findViewById(R.id.cardAvailabilityPreview)
        ivHeaderBackground = findViewById(R.id.ivHeaderBackground)
        ivLogo = findViewById(R.id.ivLogo)
        cardUpcomingBooking = findViewById(R.id.cardUpcomingBooking)
        tvUpcomingBookingInfo = findViewById(R.id.tvUpcomingBookingInfo)
        swipeRefreshHome = findViewById(R.id.swipeRefreshHome)
        fabBookNow = findViewById(R.id.fabBookNow)

        rvHomeCats = findViewById(R.id.rvHomeCats)
        rvHomeCats.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        homeCatAdapter = HomeCatAdapter(homeCatList)
        rvHomeCats.adapter = homeCatAdapter
    }

    private fun loadAllData() {
        loadBranding()
        loadUserProfile()
        loadFeaturedCats()
        loadOperatingAndAnnouncements()
        loadVisitStats()
        loadTodayAvailability()
        calculateAverageRating()
        loadUpcomingBookingReminder()
    }

    private fun setupClickListeners() {
        findViewById<View>(R.id.buttonBookTable).setOnClickListener { startActivity(Intent(this, BookingActivity::class.java)) }
        findViewById<View>(R.id.buttonFoodMenu).setOnClickListener { startActivity(Intent(this, MenuActivity::class.java)) }
        findViewById<View>(R.id.btnPublicReviews).setOnClickListener { startActivity(Intent(this, ReviewWallActivity::class.java)) }
        findViewById<View>(R.id.buttonBookingHistory).setOnClickListener { startActivity(Intent(this, CustomerBookingHistoryActivity::class.java)) }
        cardAvailabilityPreview.setOnClickListener { startActivity(Intent(this, BookingActivity::class.java)) }

        findViewById<TextView>(R.id.tvViewAllCats).setOnClickListener {
            startActivity(Intent(this, CatListActivity::class.java))
        }

        // ✅ UPDATED: Logout with Confirmation Dialog
        findViewById<ImageButton>(R.id.buttonLogout).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes") { _, _ ->
                    auth.signOut()
                    redirectToLogin()
                }
                .setNegativeButton("No", null)
                .show()
        }

        fabBookNow.setOnClickListener {
            startActivity(Intent(this, BookingActivity::class.java))
        }

        swipeRefreshHome.setColorSchemeColors(Color.parseColor("#6D4CFF"))
        swipeRefreshHome.setOnRefreshListener {
            loadAllData()
            swipeRefreshHome.postDelayed({
                swipeRefreshHome.isRefreshing = false
            }, 2000)
        }
    }

    private fun loadUpcomingBookingReminder() {
        val uid = auth.currentUser?.uid ?: return
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val todayStr = sdf.format(Date())
        val tomorrowStr = sdf.format(Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }.time)

        database.getReference("Bookings").orderByChild("userId").equalTo(uid)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var reminderBooking: DataSnapshot? = null
                    for (snap in snapshot.children) {
                        val date = snap.child("date").getValue(String::class.java) ?: continue
                        val status = snap.child("status").getValue(String::class.java) ?: continue
                        if (status == "Confirmed" && (date == todayStr || date == tomorrowStr)) {
                            reminderBooking = snap
                            break
                        }
                    }
                    if (reminderBooking != null) {
                        val time = reminderBooking.child("timeSlot").getValue(String::class.java) ?: ""
                        val guests = reminderBooking.child("guests").getValue(Int::class.java) ?: 0
                        val date = reminderBooking.child("date").getValue(String::class.java) ?: ""
                        val dayLabel = if (date == todayStr) "today" else "tomorrow"
                        tvUpcomingBookingInfo.text = "Reminder: You have a booking $dayLabel at $time for $guests guest(s)!"
                        cardUpcomingBooking.visibility = View.VISIBLE
                    } else {
                        cardUpcomingBooking.visibility = View.GONE
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun loadTodayAvailability() {
        val todayKey = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
        database.getReference("SlotCount").child(todayKey)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var totalOccupiedToday = 0
                    for (slot in snapshot.children) {
                        totalOccupiedToday += slot.getValue(Int::class.java) ?: 0
                    }
                    val totalPossibleCapacity = 5 * MAX_CAPACITY_PER_SLOT
                    val remainingSpaces = totalPossibleCapacity - totalOccupiedToday
                    tvTodayAvailability.text = if (remainingSpaces > 0) "$remainingSpaces spaces available today" else "Fully booked for today"
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun loadOperatingAndAnnouncements() {
        database.getReference("Settings").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val hours = snapshot.child("operatingHours").getValue(String::class.java) ?: "10:00 AM - 10:00 PM"
                tvOperatingStatus.text = "Open today: $hours ✅"
                val announcement = snapshot.child("announcement").getValue(String::class.java)
                if (!announcement.isNullOrEmpty()) {
                    tvAnnouncementText.text = announcement
                    cardAnnouncement.visibility = View.VISIBLE
                } else {
                    cardAnnouncement.visibility = View.GONE
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun loadVisitStats() {
        val uid = auth.currentUser?.uid ?: return
        database.getReference("Bookings").orderByChild("userId").equalTo(uid)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val count = snapshot.children.count {
                        val status = it.child("status").getValue(String::class.java)
                        status == "Completed" || status == "Confirmed"
                    }
                    tvVisitStats.text = "You've visited $count times 🐾"
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun calculateAverageRating() {
        database.getReference("Reviews").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    var totalRating = 0f
                    var count = 0
                    for (data in snapshot.children) {
                        val rating = data.child("rating").getValue(Float::class.java) ?: 0f
                        totalRating += rating
                        count++
                    }
                    tvAverageRating.text = String.format("%.1f", if (count > 0) totalRating / count else 0f)
                } else {
                    tvAverageRating.text = "0.0"
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun loadBranding() {
        val shopImg = "https://tse3.mm.bing.net/th/id/OIP.PU__x39JOLuKWygm6zJtagAAAA?pid=Api&h=220&P=0"
        val logoImg = "https://static.vecteezy.com/system/resources/previews/026/515/349/original/cat-cafe-sign-free-png.png"
        ivHeaderBackground.load(shopImg) { crossfade(true) }
        ivLogo.load(logoImg) { crossfade(true) }
    }

    private fun loadUserProfile() {
        val uid = auth.currentUser?.uid ?: return
        database.getReference("Users").child(uid).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val name = snapshot.child("name").getValue(String::class.java) ?: "Friend"
                textViewWelcome.text = "Welcome, $name! 🐱"
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun loadFeaturedCats() {
        database.getReference("Cats").limitToFirst(10).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                homeCatList.clear()
                for (data in snapshot.children) {
                    val cat = data.getValue(Cat::class.java)
                    if (cat != null) homeCatList.add(cat)
                }
                homeCatAdapter.notifyDataSetChanged()
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }
}