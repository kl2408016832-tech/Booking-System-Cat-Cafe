package com.example.catcafe

data class Review(
    val reviewId: String = "",
    val userId: String = "",
    val userName: String = "",
    val bookingId: String = "",
    val rating: Float = 0.0f,
    val comment: String = "",
    val timestamp: Long = 0L
) {
    constructor() : this("", "", "", "", 0.0f, "", 0L)
}