package com.example.catcafe

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class AdminCatAdapter(
    private val catList: List<Cat>,
    private val onDelete: (Cat) -> Unit
) : RecyclerView.Adapter<AdminCatAdapter.AdminCatViewHolder>() {

    class AdminCatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivCat: ImageView = itemView.findViewById(R.id.ivCatPhoto)
        val tvName: TextView = itemView.findViewById(R.id.tvCatName)
        val tvBreed: TextView = itemView.findViewById(R.id.tvCatBreed)
        val btnDelete: Button = itemView.findViewById(R.id.btnDeleteCat)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdminCatViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_admin_cat, parent, false)
        return AdminCatViewHolder(view)
    }

    override fun onBindViewHolder(holder: AdminCatViewHolder, position: Int) {
        val cat = catList[position]
        holder.tvName.text = cat.name
        holder.tvBreed.text = cat.breed
        
        holder.ivCat.load(cat.imageUrl) {
            placeholder(R.drawable.ic_launcher_foreground)
            error(R.drawable.ic_launcher_foreground)
        }

        holder.btnDelete.setOnClickListener { onDelete(cat) }
    }

    override fun getItemCount() = catList.size
}