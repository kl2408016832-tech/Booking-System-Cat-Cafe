package com.example.catcafe

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class CustomerBookingHistoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvBookingCount: TextView
    private lateinit var layoutEmptyState: View
    private lateinit var btnBack: ImageButton

    private val bookingList = mutableListOf<Booking>()
    private lateinit var adapter: CustomerBookingAdapter

    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking_history)

        initViews()
        setupRecyclerView()
        setupClickListeners()
        loadMyBookings()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerViewHistory)
        progressBar = findViewById(R.id.historyProgressBar)
        tvBookingCount = findViewById(R.id.tvBookingCount)
        layoutEmptyState = findViewById(R.id.layoutEmptyState)
        btnBack = findViewById(R.id.btnBack)
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = CustomerBookingAdapter(bookingList, 
            onCancel = { booking -> confirmCancelBooking(booking) },
            onReview = { booking -> showReviewDialog(booking) }
        )
        recyclerView.adapter = adapter
    }

    private fun setupClickListeners() {
        btnBack.setOnClickListener { finish() }
    }

    private fun loadMyBookings() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        progressBar.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance(DB_URL).getReference("Bookings")

        database.orderByChild("userId").equalTo(userId)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    bookingList.clear()
                    for (data in snapshot.children) {
                        val b = data.getValue(Booking::class.java)
                        if (b != null) bookingList.add(b)
                    }
                    bookingList.sortByDescending { it.timestamp }
                    adapter.notifyDataSetChanged()
                    
                    tvBookingCount.text = "${bookingList.size} total bookings"
                    progressBar.visibility = View.GONE
                    layoutEmptyState.visibility = if (bookingList.isEmpty()) View.VISIBLE else View.GONE
                }
                override fun onCancelled(error: DatabaseError) { progressBar.visibility = View.GONE }
            })
    }

    private fun confirmCancelBooking(booking: Booking) {
        AlertDialog.Builder(this)
            .setTitle("Cancel Booking?")
            .setMessage("Are you sure you want to cancel this booking? This will open up the slot for others.")
            .setPositiveButton("Yes") { _, _ ->
                // ✅ STEP 1: Update Booking Status
                FirebaseDatabase.getInstance(DB_URL).getReference("Bookings")
                    .child(booking.bookingId).child("status").setValue("Cancelled")
                    .addOnSuccessListener {
                        // ✅ STEP 2: Deduct from SlotCount so capacity increases back
                        deductSlotCount(booking.date, booking.timeSlot, booking.guests)
                        Toast.makeText(this, "Booking cancelled", Toast.LENGTH_SHORT).show()
                    }
            }
            .setNegativeButton("No", null)
            .show()
    }

    private fun deductSlotCount(date: String, slot: String, guests: Int) {
        val dateKey = date.replace("/", "-")
        val timeKey = slot.replace(":", "-").replace(" ", "_")
        val ref = FirebaseDatabase.getInstance(DB_URL).getReference("SlotCount").child(dateKey).child(timeKey)
        
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                val current = data.getValue(Int::class.java) ?: 0
                data.value = if (current >= guests) current - guests else 0
                return Transaction.success(data)
            }
            override fun onComplete(p0: DatabaseError?, p1: Boolean, p2: DataSnapshot?) {}
        })
    }

    private fun showReviewDialog(booking: Booking) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_review, null)
        val ratingBar = dialogView.findViewById<RatingBar>(R.id.ratingBar)
        val etComment = dialogView.findViewById<EditText>(R.id.etReviewComment)

        AlertDialog.Builder(this)
            .setTitle("Write a Review")
            .setView(dialogView)
            .setPositiveButton("Submit") { _, _ ->
                val rating = ratingBar.rating
                val comment = etComment.text.toString()
                if (rating > 0) saveReviewToFirebase(booking, rating, comment)
                else Toast.makeText(this, "Please give a rating", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveReviewToFirebase(booking: Booking, rating: Float, comment: String) {
        val database = FirebaseDatabase.getInstance(DB_URL).getReference("Reviews")
        val reviewId = database.push().key ?: return
        val review = Review(reviewId, booking.userId, booking.userName, booking.bookingId, rating, comment, System.currentTimeMillis())
        database.child(reviewId).setValue(review).addOnSuccessListener {
            Toast.makeText(this, "Thank you for your feedback! ⭐", Toast.LENGTH_SHORT).show()
        }
    }
}