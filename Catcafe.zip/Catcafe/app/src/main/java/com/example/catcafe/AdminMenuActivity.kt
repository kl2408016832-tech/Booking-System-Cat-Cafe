package com.example.catcafe

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.android.material.chip.ChipGroup
import com.google.firebase.database.*

class AdminMenuActivity : AppCompatActivity() {

    private lateinit var spinnerCategory: Spinner
    private lateinit var etItemName: EditText
    private lateinit var etItemPrice: EditText
    private lateinit var etImageUrl: EditText
    private lateinit var ivPreview: ImageView
    private lateinit var btnPreview: Button
    private lateinit var btnAddItem: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var recyclerView: RecyclerView
    
    private lateinit var chipGroupMenuFilter: ChipGroup

    private val masterMenuList = mutableListOf<MenuItem>() 
    private val displayList = mutableListOf<MenuItem>()   
    private lateinit var adminMenuAdapter: AdminMenuAdapter

    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_menu)

        initViews()
        setupRecyclerView()
        setupFilterLogic()
        loadAllMenuItems()

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        // ✅ ADDED "Dessert" to categories
        val categories = arrayOf("Food", "Drinks", "Dessert")
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        spinnerCategory.adapter = spinnerAdapter

        btnPreview.setOnClickListener {
            val url = etImageUrl.text.toString().trim()
            if (url.isNotEmpty()) {
                ivPreview.visibility = View.VISIBLE
                ivPreview.load(url) {
                    crossfade(true)
                    placeholder(R.drawable.ic_launcher_background)
                    error(R.drawable.ic_launcher_background)
                }
            } else {
                Toast.makeText(this, "Please enter an Image URL", Toast.LENGTH_SHORT).show()
            }
        }

        btnAddItem.setOnClickListener { validateAndAddItem() }
    }

    private fun initViews() {
        spinnerCategory = findViewById(R.id.spinnerCategory)
        etItemName = findViewById(R.id.etItemName)
        etItemPrice = findViewById(R.id.etItemPrice)
        etImageUrl = findViewById(R.id.etImageUrl)
        ivPreview = findViewById(R.id.ivImagePreview)
        btnPreview = findViewById(R.id.btnPreviewImage)
        btnAddItem = findViewById(R.id.btnAddMenuItem)
        progressBar = findViewById(R.id.adminMenuProgressBar)
        recyclerView = findViewById(R.id.recyclerViewAdminMenu)
        chipGroupMenuFilter = findViewById(R.id.chipGroupMenuFilter)
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        adminMenuAdapter = AdminMenuAdapter(displayList) { item -> confirmDeleteItem(item) }
        recyclerView.adapter = adminMenuAdapter
    }

    private fun setupFilterLogic() {
        chipGroupMenuFilter.setOnCheckedChangeListener { _, checkedId ->
            applyMenuFilter(checkedId)
        }
    }

    private fun applyMenuFilter(checkedId: Int) {
        val filtered = when (checkedId) {
            R.id.chipFood -> masterMenuList.filter { it.category == "Food" }
            R.id.chipDrinks -> masterMenuList.filter { it.category == "Drinks" }
            R.id.chipDessert -> masterMenuList.filter { it.category == "Dessert" } // ✅ Added Dessert filter
            else -> masterMenuList 
        }
        
        displayList.clear()
        displayList.addAll(filtered)
        adminMenuAdapter.notifyDataSetChanged()
    }

    private fun validateAndAddItem() {
        val name = etItemName.text.toString().trim()
        val priceText = etItemPrice.text.toString().trim()
        val url = etImageUrl.text.toString().trim()
        val category = spinnerCategory.selectedItem.toString()

        if (name.isEmpty() || priceText.isEmpty() || url.isEmpty()) {
            Toast.makeText(this, "Please complete all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val price = priceText.toDoubleOrNull() ?: 0.0
        saveMenuItemToDatabase(name, price, category, url)
    }

    private fun saveMenuItemToDatabase(name: String, price: Double, category: String, imageUrl: String) {
        progressBar.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance(DB_URL).getReference("Menu")
        val itemId = database.push().key ?: System.currentTimeMillis().toString()

        val menuItem = MenuItem(itemId, name, price, imageUrl, category)

        database.child(itemId).setValue(menuItem)
            .addOnSuccessListener {
                progressBar.visibility = View.GONE
                Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show()
                clearForm()
            }
            .addOnFailureListener { e ->
                progressBar.visibility = View.GONE
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun loadAllMenuItems() {
        progressBar.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance(DB_URL).getReference("Menu")
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                masterMenuList.clear()
                for (itemSnap in snapshot.children) {
                    val item = itemSnap.getValue(MenuItem::class.java)
                    if (item != null) masterMenuList.add(item)
                }
                masterMenuList.sortBy { it.category }
                applyMenuFilter(chipGroupMenuFilter.checkedChipId)
                progressBar.visibility = View.GONE
            }

            override fun onCancelled(error: DatabaseError) {
                progressBar.visibility = View.GONE
            }
        })
    }

    private fun confirmDeleteItem(item: MenuItem) {
        AlertDialog.Builder(this)
            .setTitle("Delete Item?")
            .setMessage("Are you sure you want to delete ${item.name}?")
            .setPositiveButton("Yes") { _, _ ->
                FirebaseDatabase.getInstance(DB_URL).getReference("Menu").child(item.itemId).removeValue()
            }
            .setNegativeButton("No", null).show()
    }

    private fun clearForm() {
        etItemName.text?.clear()
        etItemPrice.text?.clear()
        etImageUrl.text?.clear()
        ivPreview.visibility = View.GONE
    }
}