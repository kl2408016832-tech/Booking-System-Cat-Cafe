package com.example.catcafe

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class CustomerBookingAdapter(
    private var bookingList: List<Booking>,
    private val onCancel: (Booking) -> Unit,
    private val onReview: (Booking) -> Unit
) : RecyclerView.Adapter<CustomerBookingAdapter.CustomerBookingViewHolder>() {

    class CustomerBookingViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDate: TextView = itemView.findViewById(R.id.tvBookingDate)
        val tvTimeSlot: TextView = itemView.findViewById(R.id.tvBookingTimeSlot)
        val tvGuests: TextView = itemView.findViewById(R.id.tvBookingGuests)
        val tvStatus: TextView = itemView.findViewById(R.id.tvBookingStatus)
        val btnCancel: Button = itemView.findViewById(R.id.btnCancelMyBooking)
        val btnReview: Button = itemView.findViewById(R.id.btnReview)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomerBookingViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_customer_booking, parent, false)
        return CustomerBookingViewHolder(view)
    }

    override fun onBindViewHolder(holder: CustomerBookingViewHolder, position: Int) {
        val booking = bookingList[position]
        holder.tvDate.text = booking.date
        holder.tvTimeSlot.text = "🕐 ${booking.timeSlot}"
        holder.tvGuests.text = "👥 ${booking.guests} guests"

        val isPast = isDatePassed(booking.date)
        
        // Logic: Verified Review (Only if completed OR past confirmed)
        if (booking.status == "Completed" || (booking.status == "Confirmed" && isPast)) {
            holder.btnReview.visibility = View.VISIBLE
            holder.btnReview.setOnClickListener { onReview(booking) }
        } else {
            holder.btnReview.visibility = View.GONE
        }

        // Status Colors
        when (booking.status) {
            "Confirmed" -> {
                if (isPast) {
                    holder.tvStatus.text = "✨ Visited"
                    holder.tvStatus.setTextColor(Color.parseColor("#6D4CFF"))
                    holder.btnCancel.visibility = View.GONE
                } else {
                    holder.tvStatus.text = "✅ Confirmed"
                    holder.tvStatus.setTextColor(Color.parseColor("#4CAF50"))
                    holder.btnCancel.visibility = View.VISIBLE
                    holder.btnCancel.setOnClickListener { onCancel(booking) }
                }
            }
            "Cancelled" -> {
                holder.tvStatus.text = "❌ Cancelled"
                holder.tvStatus.setTextColor(Color.parseColor("#F44336"))
                holder.btnCancel.visibility = View.GONE
            }
            "Completed" -> {
                holder.tvStatus.text = "✨ Completed"
                holder.tvStatus.setTextColor(Color.parseColor("#6D4CFF"))
                holder.btnCancel.visibility = View.GONE
            }
        }
    }

    private fun isDatePassed(dateStr: String): Boolean {
        return try {
            val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val bDate = sdf.parse(dateStr)
            val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.time
            bDate != null && bDate.before(today)
        } catch (e: Exception) { false }
    }

    override fun getItemCount() = bookingList.size

    fun updateList(newList: List<Booking>) {
        bookingList = newList
        notifyDataSetChanged()
    }
}