package com.example.catcafe

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class AdminMenuAdapter(
    private var menuList: List<MenuItem>,
    private val onDelete: (MenuItem) -> Unit
) : RecyclerView.Adapter<AdminMenuAdapter.AdminMenuViewHolder>() {

    class AdminMenuViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivItem: ImageView = itemView.findViewById(R.id.ivMenuItem)
        val tvName: TextView = itemView.findViewById(R.id.tvMenuItemName)
        val tvPrice: TextView = itemView.findViewById(R.id.tvMenuItemPrice)
        val btnDelete: Button = itemView.findViewById(R.id.btnDeleteMenuItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdminMenuViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_menu, parent, false)
        return AdminMenuViewHolder(view)
    }

    override fun onBindViewHolder(holder: AdminMenuViewHolder, position: Int) {
        val item = menuList[position]

        holder.tvName.text = item.name
        holder.tvPrice.text = String.format("RM %.2f", item.price)

        holder.ivItem.load(item.imageUrl) {
            crossfade(true)
            placeholder(R.drawable.ic_launcher_foreground)
            error(R.drawable.ic_launcher_foreground)
        }

        // Handle delete action
        holder.btnDelete.setOnClickListener { 
            onDelete(item) 
        }
        
        // Ensure delete button is visible for Admin
        holder.btnDelete.visibility = View.VISIBLE
    }

    override fun getItemCount() = menuList.size

    fun updateList(newList: List<MenuItem>) {
        menuList = newList
        notifyDataSetChanged()
    }
}