package com.example.catcafe

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.chip.ChipGroup
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*

class AdminActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvTotalBookings: TextView
    private lateinit var tvTotalUsers: TextView
    private lateinit var tvStatsToday: TextView
    private lateinit var tvStatsWeekly: TextView
    private lateinit var tvStatsMonthly: TextView
    private lateinit var tvTodaySummary: TextView
    private lateinit var tvOccupancySummary: TextView
    private lateinit var tvAdminCurrentDate: TextView
    private lateinit var etAnnouncement: EditText
    private lateinit var btnUpdateAnnouncement: Button
    private lateinit var etOperatingHours: EditText
    private lateinit var btnUpdateHours: Button
    private lateinit var btnLogout: ImageButton
    private lateinit var chipGroupFilter: ChipGroup

    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var etSearchBooking: EditText
    private lateinit var layoutEmptyState: LinearLayout

    private val slotViewMap = mutableMapOf<String, Pair<TextView, View>>()
    private val masterBookingList = mutableListOf<Booking>()
    private val displayList = mutableListOf<Booking>()
    private lateinit var adapter: AdminBookingAdapter
    private lateinit var auth: FirebaseAuth

    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"
    private val MAX_CAPACITY = 30

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        auth = FirebaseAuth.getInstance()
        checkAdminRole()

        initViews()
        setupRecyclerView()
        setupClickListeners()
        setupFilterLogic()
        setupSearchBar()
        setupSwipeRefresh()

        loadAllData()
        checkTodaysOccupancy()
        loadCurrentSettings()
    }

    private fun checkAdminRole() {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            redirectToLogin()
            return
        }
        FirebaseDatabase.getInstance(DB_URL).getReference("Users").child(uid)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.child("role").getValue(String::class.java) != "Admin") {
                        Toast.makeText(this@AdminActivity, "Access Denied", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
                override fun onCancelled(error: DatabaseError) { finish() }
            })
    }

    private fun redirectToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerViewAdmin)
        progressBar = findViewById(R.id.adminProgressBar)
        tvTotalBookings = findViewById(R.id.tvTotalBookings)
        tvTotalUsers = findViewById(R.id.tvTotalUsers)
        tvStatsToday = findViewById(R.id.tvStatsToday)
        tvStatsWeekly = findViewById(R.id.tvStatsWeekly)
        tvStatsMonthly = findViewById(R.id.tvStatsMonthly)
        tvTodaySummary = findViewById(R.id.tvTodaySummary)
        tvOccupancySummary = findViewById(R.id.tvOccupancySummary)
        tvAdminCurrentDate = findViewById(R.id.tvAdminCurrentDate)
        
        val dateFormat = SimpleDateFormat("EEEE, dd MMM yyyy", Locale.getDefault())
        tvAdminCurrentDate.text = dateFormat.format(Date())
        
        etAnnouncement = findViewById(R.id.etAnnouncement)
        btnUpdateAnnouncement = findViewById(R.id.btnUpdateAnnouncement)
        etOperatingHours = findViewById(R.id.etOperatingHours)
        btnUpdateHours = findViewById(R.id.btnUpdateHours)
        chipGroupFilter = findViewById(R.id.chipGroupFilter)
        btnLogout = findViewById(R.id.btnAdminLogout)
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)
        etSearchBooking = findViewById(R.id.etSearchBooking)
        layoutEmptyState = findViewById(R.id.layoutEmptyState)

        setupSlotMap()
    }

    private fun setupSlotMap() {
        val slots = listOf("10:00 AM", "12:00 PM", "02:00 PM", "04:00 PM", "06:00 PM")
        val ids = listOf(R.id.slot10AM, R.id.slot12PM, R.id.slot02PM, R.id.slot04PM, R.id.slot06PM)
        for (i in slots.indices) {
            val view = findViewById<View>(ids[i])
            val tvCount = view.findViewById<TextView>(R.id.tvSlotCount)
            val tvTime = view.findViewById<TextView>(R.id.tvSlotTime)
            tvTime.text = slots[i]
            slotViewMap[slots[i]] = Pair(tvCount, view)
        }
    }

    private fun setupSwipeRefresh() {
        swipeRefreshLayout.setColorSchemeColors(Color.parseColor("#D2B48C"))
        swipeRefreshLayout.setOnRefreshListener {
            loadAllData()
            checkTodaysOccupancy()
            loadCurrentSettings()
        }
    }

    private fun setupSearchBar() {
        etSearchBooking.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { filterBySearch(s.toString().trim().lowercase()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun filterBySearch(query: String) {
        val chipFiltered = when (chipGroupFilter.checkedChipId) {
            R.id.chipConfirmed -> masterBookingList.filter { it.status == "Confirmed" }
            R.id.chipCompleted -> masterBookingList.filter { it.status == "Completed" }
            R.id.chipCancelled -> masterBookingList.filter { it.status == "Cancelled" } // ✅ New
            R.id.chipArrived -> masterBookingList.filter { it.status == "Arrived" }     // ✅ New
            else -> masterBookingList
        }
        val result = if (query.isEmpty()) chipFiltered
        else chipFiltered.filter { it.userName.lowercase().contains(query) }

        displayList.clear()
        displayList.addAll(result)
        adapter.notifyDataSetChanged()
        
        layoutEmptyState.visibility = if (displayList.isEmpty()) View.VISIBLE else View.GONE
        recyclerView.visibility = if (displayList.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun checkTodaysOccupancy() {
        val todayKey = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
        FirebaseDatabase.getInstance(DB_URL).getReference("SlotCount").child(todayKey)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var totalOccupied = 0
                    slotViewMap.forEach { (_, pair) ->
                        pair.first.text = "$MAX_CAPACITY left"
                        pair.second.setBackgroundColor(Color.parseColor("#F1F8E9"))
                    }
                    for (slotSnap in snapshot.children) {
                        val count = slotSnap.getValue(Int::class.java) ?: 0
                        totalOccupied += count
                        val timeKey = slotSnap.key?.replace("-", ":")?.replace("_", " ")
                        slotViewMap[timeKey]?.let {
                            val left = MAX_CAPACITY - count
                            it.first.text = if (left > 0) "$left left" else "FULL"
                            if (left <= 0) it.second.setBackgroundColor(Color.parseColor("#EF5350"))
                            else if (left <= 5) it.second.setBackgroundColor(Color.parseColor("#FFF9C4"))
                        }
                    }
                    tvOccupancySummary.text = "Live tracking: $totalOccupied pax booked for today"
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun loadAllData() {
        progressBar.visibility = View.VISIBLE
        FirebaseDatabase.getInstance(DB_URL).getReference("Bookings")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    masterBookingList.clear()
                    val userIds = mutableSetOf<String>()
                    if (snapshot.exists()) {
                        for (data in snapshot.children) {
                            val b = data.getValue(Booking::class.java)
                            if (b != null) {
                                masterBookingList.add(b)
                                if (b.status != "Cancelled") userIds.add(b.userId)
                            }
                        }
                        masterBookingList.sortByDescending { it.timestamp }
                        filterBySearch(etSearchBooking.text.toString().trim().lowercase())
                        calculateDetailedStats(userIds.size)
                    } else {
                        displayList.clear()
                        adapter.notifyDataSetChanged()
                        layoutEmptyState.visibility = View.VISIBLE
                    }
                    progressBar.visibility = View.GONE
                    swipeRefreshLayout.isRefreshing = false
                }
                override fun onCancelled(error: DatabaseError) { 
                    progressBar.visibility = View.GONE 
                    swipeRefreshLayout.isRefreshing = false
                }
            })
    }

    private fun calculateDetailedStats(userCount: Int) {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val todayStr = sdf.format(Date())
        val validBookings = masterBookingList.filter { it.status != "Cancelled" }
        val todayBookings = validBookings.filter { it.date == todayStr }

        tvStatsToday.text = todayBookings.size.toString()
        tvTodaySummary.text = "Today: ${todayBookings.size} bookings • ${todayBookings.sumOf { it.guests }} guests"
        
        val cal = Calendar.getInstance()
        val monthAgo = cal.apply { add(Calendar.MONTH, -1) }.time
        val weekAgo = cal.apply { add(Calendar.DAY_OF_YEAR, -7) }.time

        tvStatsWeekly.text = validBookings.count { sdf.parse(it.date)?.after(weekAgo) == true }.toString()
        tvStatsMonthly.text = validBookings.count { sdf.parse(it.date)?.after(monthAgo) == true }.toString()
        tvTotalBookings.text = validBookings.size.toString()
        tvTotalUsers.text = userCount.toString()
    }

    private fun loadCurrentSettings() {
        FirebaseDatabase.getInstance(DB_URL).getReference("Settings").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                etAnnouncement.setText(s.child("announcement").getValue(String::class.java) ?: "")
                etOperatingHours.setText(s.child("operatingHours").getValue(String::class.java) ?: "")
            }
            override fun onCancelled(e: DatabaseError) {}
        })
    }

    private fun setupClickListeners() {
        btnUpdateAnnouncement.setOnClickListener {
            val msg = etAnnouncement.text.toString().trim()
            FirebaseDatabase.getInstance(DB_URL).getReference("Settings/announcement").setValue(msg)
                .addOnSuccessListener { Toast.makeText(this, "Notice Updated!", Toast.LENGTH_SHORT).show() }
        }
        btnUpdateHours.setOnClickListener {
            val hours = etOperatingHours.text.toString().trim()
            FirebaseDatabase.getInstance(DB_URL).getReference("Settings/operatingHours").setValue(hours)
                .addOnSuccessListener { Toast.makeText(this, "Hours Updated!", Toast.LENGTH_SHORT).show() }
        }
        btnLogout.setOnClickListener {
            auth.signOut()
            redirectToLogin()
        }
        findViewById<View>(R.id.btnManageCatsCard).setOnClickListener { startActivity(Intent(this, AdminCatActivity::class.java)) }
        findViewById<View>(R.id.btnManageMenuCard).setOnClickListener { startActivity(Intent(this, AdminMenuActivity::class.java)) }
        findViewById<View>(R.id.btnViewReviewsCard).setOnClickListener { startActivity(Intent(this, AdminReviewActivity::class.java)) }
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AdminBookingAdapter(displayList, { b, s -> updateStatus(b, s) }, { b -> deleteBooking(b) })
        recyclerView.adapter = adapter
    }

    private fun setupFilterLogic() {
        chipGroupFilter.setOnCheckedChangeListener { _, _ -> filterBySearch(etSearchBooking.text.toString()) }
    }

    private fun updateStatus(booking: Booking, newStatus: String) {
        if (booking.status != "Cancelled" && newStatus == "Cancelled") {
            deductSlotCount(booking.date, booking.timeSlot, booking.guests)
        }
        FirebaseDatabase.getInstance(DB_URL).getReference("Bookings").child(booking.bookingId).child("status").setValue(newStatus)
    }

    private fun deleteBooking(booking: Booking) {
        if (booking.status != "Cancelled") {
            deductSlotCount(booking.date, booking.timeSlot, booking.guests)
        }
        FirebaseDatabase.getInstance(DB_URL).getReference("Bookings").child(booking.bookingId).removeValue()
    }

    private fun deductSlotCount(date: String, slot: String, guests: Int) {
        val dateKey = date.replace("/", "-")
        val timeKey = slot.replace(":", "-").replace(" ", "_")
        val ref = FirebaseDatabase.getInstance(DB_URL).getReference("SlotCount").child(dateKey).child(timeKey)
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                val current = data.getValue(Int::class.java) ?: 0
                data.value = (current - guests).coerceAtLeast(0)
                return Transaction.success(data)
            }
            override fun onComplete(p0: DatabaseError?, p1: Boolean, p2: DataSnapshot?) {}
        })
    }
}