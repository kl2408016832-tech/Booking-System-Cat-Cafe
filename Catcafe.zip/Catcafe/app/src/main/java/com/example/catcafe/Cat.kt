package com.example.catcafe

data class Cat(
    val catId: String = "",
    val name: String = "",
    val breed: String = "",
    val description: String = "",
    val imageUrl: String = ""
) {
    // Constructor kosong untuk Firebase
    constructor() : this("", "", "", "", "")
}