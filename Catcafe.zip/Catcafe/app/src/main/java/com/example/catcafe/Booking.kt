package com.example.catcafe

data class Booking(
    var bookingId: String = "",
    var userId: String = "",
    var userName: String = "",
    var userPhone: String = "",
    var date: String = "",
    var timeSlot: String = "",
    var guests: Int = 0,
    var area: String = "",
    var specialRequest: String = "",
    var totalPrice: Double = 0.0,
    var status: String = "Confirmed",
    var timestamp: Long = 0L
) {
    // Constructor kosong untuk Firebase
    constructor() : this("", "", "", "", "", "", 0, "", "", 0.0, "Confirmed", 0L)
}