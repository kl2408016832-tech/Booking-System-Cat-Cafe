package com.example.catcafe

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.RoundedCornersTransformation

class CatProfileAdapter(private val catList: List<Cat>) :
    RecyclerView.Adapter<CatProfileAdapter.CatViewHolder>() {

    class CatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivCatPhoto: ImageView = itemView.findViewById(R.id.ivCatPhoto)
        val tvCatName: TextView = itemView.findViewById(R.id.tvCatName)
        val tvCatBreed: TextView = itemView.findViewById(R.id.tvCatBreed)
        val tvCatDescription: TextView = itemView.findViewById(R.id.tvCatDescription)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CatViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cat, parent, false)
        return CatViewHolder(view)
    }

    override fun onBindViewHolder(holder: CatViewHolder, position: Int) {
        val cat = catList[position]
        holder.tvCatName.text = cat.name
        holder.tvCatBreed.text = cat.breed
        holder.tvCatDescription.text = cat.description

        // ✅ Guna Coil untuk load gambar dari URL (sama ada link internet atau Firebase Storage)
        holder.ivCatPhoto.load(cat.imageUrl) {
            crossfade(true)
            placeholder(R.drawable.ic_launcher_background)
            error(R.drawable.ic_launcher_background)
            transformations(RoundedCornersTransformation(16f)) 
        }
    }

    override fun getItemCount() = catList.size
}