package com.example.catcafe

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class AdminReviewActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private val reviewList = mutableListOf<Review>()
    private lateinit var adapter: ReviewAdapter

    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_reviews)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        recyclerView = findViewById(R.id.recyclerViewReviews)
        progressBar = findViewById(R.id.reviewsProgressBar)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ReviewAdapter(reviewList)
        recyclerView.adapter = adapter

        loadReviews()
    }

    private fun loadReviews() {
        progressBar.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance(DB_URL).getReference("Reviews")

        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                reviewList.clear()
                for (data in snapshot.children) {
                    val review = data.getValue(Review::class.java)
                    if (review != null) reviewList.add(review)
                }
                reviewList.sortByDescending { it.timestamp }
                adapter.notifyDataSetChanged()
                progressBar.visibility = View.GONE
            }

            override fun onCancelled(error: DatabaseError) {
                progressBar.visibility = View.GONE
                Toast.makeText(this@AdminReviewActivity, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}