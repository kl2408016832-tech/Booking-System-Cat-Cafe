package com.example.catcafe

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class CatListActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var etSearch: EditText
    
    private val catList = mutableListOf<Cat>()
    private val fullCatList = mutableListOf<Cat>() // ✅ Simpan list penuh untuk filtering
    private lateinit var adapter: CatProfileAdapter
    
    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cat_list)

        initViews()
        setupSearch()
        fetchCatsFromFirebase()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerViewCats)
        progressBar = findViewById(R.id.catProgressBar)
        etSearch = findViewById(R.id.etSearchCats)
        
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        recyclerView.layoutManager = GridLayoutManager(this, 2)
        adapter = CatProfileAdapter(catList)
        recyclerView.adapter = adapter
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterCats(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterCats(query: String) {
        val filtered = if (query.isEmpty()) {
            fullCatList
        } else {
            fullCatList.filter { 
                it.name.contains(query, ignoreCase = true) || 
                it.breed.contains(query, ignoreCase = true) 
            }
        }
        catList.clear()
        catList.addAll(filtered)
        adapter.notifyDataSetChanged()
    }

    private fun fetchCatsFromFirebase() {
        progressBar.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance(DB_URL).getReference("Cats")

        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                fullCatList.clear()
                for (catSnap in snapshot.children) {
                    val cat = catSnap.getValue(Cat::class.java)
                    if (cat != null) fullCatList.add(cat)
                }
                
                // Show all cats initially
                catList.clear()
                catList.addAll(fullCatList)
                adapter.notifyDataSetChanged()
                progressBar.visibility = View.GONE
            }

            override fun onCancelled(error: DatabaseError) {
                progressBar.visibility = View.GONE
                Toast.makeText(this@CatListActivity, "Failed to load cats", Toast.LENGTH_SHORT).show()
            }
        })
    }
}