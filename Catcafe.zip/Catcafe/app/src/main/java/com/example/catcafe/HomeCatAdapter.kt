package com.example.catcafe

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class HomeCatAdapter(private val catList: List<Cat>) : RecyclerView.Adapter<HomeCatAdapter.HomeCatViewHolder>() {

    class HomeCatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivCat: ImageView = itemView.findViewById(R.id.ivCatHome)
        val tvName: TextView = itemView.findViewById(R.id.tvCatNameHome)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeCatViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cat_home, parent, false)
        return HomeCatViewHolder(view)
    }

    override fun onBindViewHolder(holder: HomeCatViewHolder, position: Int) {
        val cat = catList[position]
        holder.tvName.text = cat.name
        holder.ivCat.load(cat.imageUrl) {
            crossfade(true)
            placeholder(R.drawable.ic_launcher_background)
            error(R.drawable.ic_launcher_background)
        }
    }

    override fun getItemCount() = catList.size
}