package com.example.catcafe

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    private lateinit var editTextName: TextInputEditText
    private lateinit var editTextPhone: TextInputEditText
    private lateinit var editTextEmail: TextInputEditText
    private lateinit var editTextPassword: TextInputEditText
    private lateinit var editTextConfirmPassword: TextInputEditText
    private lateinit var buttonRegister: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var textViewError: TextView
    private lateinit var ivRegisterHeader: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        auth = FirebaseAuth.getInstance()
        initViews()
        loadHeaderImage()
        setupClickListeners()
    }

    private fun initViews() {
        editTextName = findViewById(R.id.editTextName)
        editTextPhone = findViewById(R.id.editTextPhone)
        editTextEmail = findViewById(R.id.editTextEmail)
        editTextPassword = findViewById(R.id.editTextPassword)
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword)
        buttonRegister = findViewById(R.id.buttonRegister)
        progressBar = findViewById(R.id.progressBar)
        textViewError = findViewById(R.id.textViewError)
        ivRegisterHeader = findViewById(R.id.ivRegisterHeader)
    }

    private fun loadHeaderImage() {
        val shopImageUrl = "https://tse3.mm.bing.net/th/id/OIP.PU__x39JOLuKWygm6zJtagAAAA?pid=Api&h=220&P=0"
        ivRegisterHeader.load(shopImageUrl) {
            crossfade(true)
            placeholder(R.drawable.ic_launcher_background)
        }
    }

    private fun setupClickListeners() {
        buttonRegister.setOnClickListener { validateAndRegister() }
        findViewById<TextView>(R.id.textViewLogin).setOnClickListener { finish() }
    }

    private fun validateAndRegister() {
        val name = editTextName.text.toString().trim()
        val phone = editTextPhone.text.toString().trim()
        val email = editTextEmail.text.toString().trim()
        val password = editTextPassword.text.toString().trim()
        val confirmPassword = editTextConfirmPassword.text.toString().trim()

        if (name.isEmpty() || phone.isEmpty() || email.isEmpty() || password.isEmpty()) {
            showError(getString(R.string.err_complete_info))
            return
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError(getString(R.string.err_invalid_email))
            return
        }

        val passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d).{6,}\$".toRegex()
        if (!password.matches(passwordRegex)) {
            showError("Password must be at least 6 characters and contain both letters and numbers.")
            return
        }

        if (password != confirmPassword) {
            showError(getString(R.string.err_password_mismatch))
            return
        }

        textViewError.visibility = View.GONE
        checkPhoneAndRegister(email, password, name, phone)
    }

    private fun checkPhoneAndRegister(email: String, pass: String, name: String, phone: String) {
        showLoading(true)
        val usersRef = FirebaseDatabase.getInstance(DB_URL).getReference("Users")
        
        usersRef.orderByChild("phone").equalTo(phone)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        showLoading(false)
                        showError("Phone number already registered")
                    } else {
                        performRegistration(email, pass, name, phone)
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                    showLoading(false)
                    showError(error.message)
                }
            })
    }

    private fun performRegistration(email: String, pass: String, name: String, phone: String) {
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    saveUserToDb(name, phone, email)
                } else {
                    showLoading(false)
                    if (task.exception is FirebaseAuthUserCollisionException) {
                        showError(getString(R.string.already_have_account))
                    } else {
                        showError(task.exception?.message ?: getString(R.string.error_message))
                    }
                }
            }
    }

    private fun saveUserToDb(name: String, phone: String, email: String) {
        val uid = auth.currentUser?.uid ?: return
        val userMap = mapOf(
            "uid" to uid,
            "name" to name,
            "phone" to phone,
            "email" to email,
            "role" to "Customer"
        )

        FirebaseDatabase.getInstance(DB_URL).getReference("Users").child(uid)
            .setValue(userMap)
            .addOnSuccessListener {
                showLoading(false)
                Toast.makeText(this, getString(R.string.registration_success), Toast.LENGTH_SHORT).show()
                val intent = Intent(this, HomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .addOnFailureListener { e ->
                showLoading(false)
                showError(e.message ?: getString(R.string.error_message))
            }
    }

    private fun showError(message: String) {
        textViewError.text = message
        textViewError.visibility = View.VISIBLE
    }

    private fun showLoading(loading: Boolean) {
        progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        buttonRegister.isEnabled = !loading
    }
}