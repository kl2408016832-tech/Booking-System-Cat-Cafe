package com.example.catcafe

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class ReviewWallActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvNoReviews: TextView
    private val reviewList = mutableListOf<Review>()
    private lateinit var adapter: ReviewAdapter

    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review_wall)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        recyclerView = findViewById(R.id.rvReviewWall)
        progressBar = findViewById(R.id.wallProgressBar)
        tvNoReviews = findViewById(R.id.tvNoReviews)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ReviewAdapter(reviewList)
        recyclerView.adapter = adapter

        loadAllReviews()
    }

    private fun loadAllReviews() {
        progressBar.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance(DB_URL).getReference("Reviews")

        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                reviewList.clear()
                if (snapshot.exists()) {
                    for (data in snapshot.children) {
                        val review = data.getValue(Review::class.java)
                        if (review != null) reviewList.add(review)
                    }
                    reviewList.sortByDescending { it.timestamp }
                    adapter.notifyDataSetChanged()
                    tvNoReviews.visibility = View.GONE
                } else {
                    tvNoReviews.visibility = View.VISIBLE
                }
                progressBar.visibility = View.GONE
            }

            override fun onCancelled(error: DatabaseError) {
                progressBar.visibility = View.GONE
                Toast.makeText(this@ReviewWallActivity, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}