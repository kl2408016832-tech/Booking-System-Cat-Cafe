package com.example.catcafe

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class MenuActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var etSearch: EditText
    private lateinit var tvEmpty: TextView

    private lateinit var tabFood: TextView
    private lateinit var tabDrinks: TextView
    private lateinit var tabCats: TextView
    private lateinit var tabDessert: TextView // ✅ TAMBAH

    private val fullMenuList = mutableListOf<MenuItem>()
    private val displayList = mutableListOf<MenuItem>()
    private lateinit var adapter: MenuAdapter

    private var currentCategory = "Food"
    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food_menu)

        initViews()
        setupTabs()
        setupSearch()
        loadMenuFromFirebase()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerViewMenu)
        progressBar = findViewById(R.id.menuProgressBar)
        etSearch = findViewById(R.id.etSearchMenu)
        tvEmpty = findViewById(R.id.tvMenuEmptyState)

        tabFood = findViewById(R.id.tabFood)
        tabDrinks = findViewById(R.id.tabDrinks)
        tabCats = findViewById(R.id.tabCats)
        tabDessert = findViewById(R.id.tabDessert) // ✅ TAMBAH

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MenuAdapter(displayList)
        recyclerView.adapter = adapter

        updateTabUI()
    }

    private fun setupTabs() {
        tabFood.setOnClickListener { switchCategory("Food") }
        tabDrinks.setOnClickListener { switchCategory("Drinks") }
        tabDessert.setOnClickListener { switchCategory("Dessert") } // ✅ TAMBAH
        tabCats.setOnClickListener {
            startActivity(Intent(this, CatListActivity::class.java))
        }
    }

    private fun switchCategory(category: String) {
        currentCategory = category
        updateTabUI()
        filterMenu(etSearch.text.toString())
    }

    private fun updateTabUI() {
        val selectedBg = ContextCompat.getDrawable(this, R.drawable.tab_selected)
        val unselectedBg = ContextCompat.getDrawable(this, R.drawable.tab_unselected)
        val colorWhite = ContextCompat.getColor(this, R.color.white)
        val colorGray = ContextCompat.getColor(this, android.R.color.darker_gray)

        // ✅ TAMBAH tabDessert dalam updateTabUI
        val tabs = mapOf(
            tabFood to "Food",
            tabDrinks to "Drinks",
            tabDessert to "Dessert"
        )

        for ((tab, category) in tabs) {
            if (currentCategory == category) {
                tab.background = selectedBg
                tab.setTextColor(colorWhite)
            } else {
                tab.background = unselectedBg
                tab.setTextColor(colorGray)
            }
        }
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { filterMenu(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun filterMenu(query: String) {
        val filtered = fullMenuList.filter {
            it.category == currentCategory && it.name.contains(query, ignoreCase = true)
        }
        displayList.clear()
        displayList.addAll(filtered)
        adapter.notifyDataSetChanged()

        tvEmpty.visibility = if (displayList.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun loadMenuFromFirebase() {
        progressBar.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance(DB_URL).getReference("Menu")

        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                fullMenuList.clear()
                for (itemSnap in snapshot.children) {
                    val item = itemSnap.getValue(MenuItem::class.java)
                    if (item != null) fullMenuList.add(item)
                }
                filterMenu(etSearch.text.toString())
                progressBar.visibility = View.GONE
            }
            override fun onCancelled(error: DatabaseError) {
                progressBar.visibility = View.GONE
            }
        })
    }
}