package com.example.catcafe

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.firebase.database.*

class AdminCatActivity : AppCompatActivity() {

    private lateinit var etCatName: EditText
    private lateinit var etCatBreed: EditText
    private lateinit var etCatDesc: EditText
    private lateinit var etCatImageUrl: EditText
    private lateinit var ivCatPreview: ImageView
    private lateinit var btnPreview: Button
    private lateinit var btnAddCat: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var recyclerView: RecyclerView

    private val catList = mutableListOf<Cat>()
    private lateinit var adapter: AdminCatAdapter
    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_cat)

        initViews()
        setupRecyclerView()
        loadCatsFromFirebase()

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        btnPreview.setOnClickListener {
            // ✅ FI Changed etImageUrl to etCatImageUrl
            val url = etCatImageUrl.text.toString().trim()
            if (url.isNotEmpty()) {
                ivCatPreview.visibility = View.VISIBLE
                ivCatPreview.load(url) {
                    crossfade(true)
                    placeholder(R.drawable.ic_launcher_background)
                    error(R.drawable.ic_launcher_background)
                }
            } else {
                Toast.makeText(this, "Please enter an Image URL", Toast.LENGTH_SHORT).show()
            }
        }

        btnAddCat.setOnClickListener { validateAndAddCat() }
    }

    private fun initViews() {
        etCatName = findViewById(R.id.etCatName)
        etCatBreed = findViewById(R.id.etCatBreed)
        etCatDesc = findViewById(R.id.etCatDesc)
        etCatImageUrl = findViewById(R.id.etCatImageUrl)
        ivCatPreview = findViewById(R.id.ivCatPreview)
        btnPreview = findViewById(R.id.btnPreviewCatImage)
        btnAddCat = findViewById(R.id.btnAddCat)
        progressBar = findViewById(R.id.adminCatProgressBar)
        recyclerView = findViewById(R.id.recyclerViewAdminCats)
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AdminCatAdapter(catList) { cat -> confirmDeleteCat(cat) }
        recyclerView.adapter = adapter
    }

    private fun validateAndAddCat() {
        val name = etCatName.text.toString().trim()
        val breed = etCatBreed.text.toString().trim()
        val desc = etCatDesc.text.toString().trim()
        val url = etCatImageUrl.text.toString().trim()

        if (name.isEmpty() || url.isEmpty()) {
            Toast.makeText(this, "Name and Image URL are required", Toast.LENGTH_SHORT).show()
            return
        }

        saveCatToFirebase(name, breed, desc, url)
    }

    private fun saveCatToFirebase(name: String, breed: String, desc: String, url: String) {
        progressBar.visibility = View.VISIBLE
        val ref = FirebaseDatabase.getInstance(DB_URL).getReference("Cats")
        val catId = ref.push().key ?: System.currentTimeMillis().toString()

        val cat = Cat(catId, name, breed, desc, url)

        ref.child(catId).setValue(cat).addOnSuccessListener {
            progressBar.visibility = View.GONE
            Toast.makeText(this, "Cat added successfully!", Toast.LENGTH_SHORT).show()
            clearForm()
        }
    }

    private fun loadCatsFromFirebase() {
        FirebaseDatabase.getInstance(DB_URL).getReference("Cats")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    catList.clear()
                    for (snap in snapshot.children) {
                        val cat = snap.getValue(Cat::class.java)
                        if (cat != null) catList.add(cat)
                    }
                    adapter.notifyDataSetChanged()
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun confirmDeleteCat(cat: Cat) {
        AlertDialog.Builder(this)
            .setTitle("Delete Cat?")
            .setMessage("Are you sure you want to delete ${cat.name}?")
            .setPositiveButton("Delete") { _, _ ->
                FirebaseDatabase.getInstance(DB_URL).getReference("Cats")
                    .child(cat.catId).removeValue()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun clearForm() {
        etCatName.setText("")
        etCatBreed.setText("")
        etCatDesc.setText("")
        etCatImageUrl.setText("")
        ivCatPreview.visibility = View.GONE
    }
}