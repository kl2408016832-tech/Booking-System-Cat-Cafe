package com.example.catcafe

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*

class BookingActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var calendarView: CalendarView
    private lateinit var tvDateStatus: TextView
    private lateinit var spinnerTimeSlots: Spinner
    private lateinit var etGuests: EditText
    private lateinit var btnConfirmBooking: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvCafeHoursBanner: TextView

    private var selectedDate = ""
    private var userName = ""
    private var userPhone = ""
    private var currentOpHours = "10:00 AM - 10:00 PM"

    private val MAX_GUESTS_PER_BOOKING = 20
    private val CAFE_MAX_CAPACITY = 30
    private val TOTAL_DAILY_CAPACITY = 150
    private var currentSlotOccupancy = 0

    private val allTimeSlots = arrayOf("10:00 AM", "12:00 PM", "02:00 PM", "04:00 PM", "06:00 PM")
    private val CHANNEL_ID = "booking_notification"
    private val DB_URL = "https://bookingsystemcatcafe-bd72e-default-rtdb.asia-southeast1.firebasedatabase.app/"

    private var occupancyListener: ValueEventListener? = null
    private var occupancyRef: DatabaseReference? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking)

        auth = FirebaseAuth.getInstance()
        createNotificationChannel()
        initViews()
        setupCalendar()
        setupClickListeners()
        fetchUserInfo()
        loadOperatingHours()

        btnConfirmBooking.isEnabled = false
        btnConfirmBooking.alpha = 0.5f
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOccupancyListener()
    }

    private fun removeOccupancyListener() {
        if (occupancyListener != null && occupancyRef != null) {
            occupancyRef!!.removeEventListener(occupancyListener!!)
            occupancyListener = null
            occupancyRef = null
        }
    }

    private fun initViews() {
        calendarView = findViewById(R.id.calendarView)
        tvDateStatus = findViewById(R.id.tvDateStatus)
        spinnerTimeSlots = findViewById(R.id.spinnerTimeSlots)
        etGuests = findViewById(R.id.etGuests)
        btnConfirmBooking = findViewById(R.id.btnConfirmBooking)
        progressBar = findViewById(R.id.bookingProgressBar)
        tvCafeHoursBanner = findViewById(R.id.tvCafeHoursBanner)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
        calendarView.minDate = System.currentTimeMillis() - 1000
    }

    private fun loadOperatingHours() {
        FirebaseDatabase.getInstance(DB_URL).getReference("Settings/operatingHours")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    currentOpHours = snapshot.getValue(String::class.java) ?: "10:00 AM - 10:00 PM"
                    tvCafeHoursBanner.text = "Operating Hours: $currentOpHours"
                    updateTimeSlotsSpinner()
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun updateTimeSlotsSpinner() {
        if (selectedDate.isEmpty()) {
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Select a date first"))
            spinnerTimeSlots.adapter = adapter
            return
        }

        val dateKey = selectedDate.replace("/", "-")
        FirebaseDatabase.getInstance(DB_URL).getReference("SlotCount").child(dateKey)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val displaySlots = mutableListOf("Select a time slot")
                    val sdfDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                    val todayStr = sdfDate.format(Date())
                    val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

                    val parts = currentOpHours.split("-")
                    val openTime = if (parts.size == 2) timeFormat.parse(parts[0].trim()) else null
                    val closeTime = if (parts.size == 2) timeFormat.parse(parts[1].trim()) else null

                    val now = Calendar.getInstance()

                    for (slot in allTimeSlots) {
                        try {
                            val slotDateObj = timeFormat.parse(slot) ?: continue
                            
                            val isWithinHours = if (openTime != null && closeTime != null) {
                                !slotDateObj.before(openTime) && !slotDateObj.after(closeTime)
                            } else true

                            var isFuture = true
                            if (selectedDate == todayStr) {
                                val slotCal = Calendar.getInstance().apply {
                                    time = slotDateObj
                                    set(Calendar.YEAR, now.get(Calendar.YEAR))
                                    set(Calendar.MONTH, now.get(Calendar.MONTH))
                                    set(Calendar.DAY_OF_MONTH, now.get(Calendar.DAY_OF_MONTH))
                                }
                                isFuture = slotCal.after(now)
                            }

                            if (isWithinHours && isFuture) {
                                val timeKey = slot.replace(":", "-").replace(" ", "_")
                                val occupied = snapshot.child(timeKey).getValue(Int::class.java) ?: 0
                                val left = CAFE_MAX_CAPACITY - occupied
                                val statusText = if (left <= 0) "(Full)" else "($left left)"
                                displaySlots.add("$slot $statusText")
                            }
                        } catch (e: Exception) {}
                    }

                    val adapter = ArrayAdapter(this@BookingActivity, android.R.layout.simple_spinner_dropdown_item, displaySlots)
                    spinnerTimeSlots.adapter = adapter
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun setupCalendar() {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        selectedDate = sdf.format(Date())
        checkDailyOccupancyRealtime()
        updateTimeSlotsSpinner()

        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            selectedDate = String.format(Locale.getDefault(), "%02d/%02d/%d", dayOfMonth, month + 1, year)
            removeOccupancyListener()
            checkDailyOccupancyRealtime()
            updateTimeSlotsSpinner()
        }
    }

    private fun checkDailyOccupancyRealtime() {
        if (selectedDate.isEmpty()) return
        val dateKey = selectedDate.replace("/", "-")
        val ref = FirebaseDatabase.getInstance(DB_URL).getReference("SlotCount").child(dateKey)

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var totalBooked = 0
                for (slot in snapshot.children) {
                    totalBooked += slot.getValue(Int::class.java) ?: 0
                }

                if (totalBooked >= TOTAL_DAILY_CAPACITY) {
                    tvDateStatus.text = "Status: FULLY BOOKED ❌"
                    tvDateStatus.setTextColor(Color.RED)
                } else {
                    val left = TOTAL_DAILY_CAPACITY - totalBooked
                    tvDateStatus.text = "Status: Available ($left spaces left) ✅"
                    tvDateStatus.setTextColor(Color.parseColor("#4CAF50"))
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }

        occupancyRef = ref
        occupancyListener = listener
        ref.addValueEventListener(listener)
    }

    private fun setupClickListeners() {
        spinnerTimeSlots.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, pos: Int, p3: Long) {
                if (pos > 0) checkSlotOccupancy()
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }

        etGuests.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { validateFinalSelection() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        btnConfirmBooking.setOnClickListener { attemptBooking() }
    }

    private fun checkSlotOccupancy() {
        if (selectedDate.isEmpty() || spinnerTimeSlots.selectedItemPosition == 0) return
        val rawSelected = spinnerTimeSlots.selectedItem.toString()
        val timeSlot = rawSelected.split(" (")[0]
        val slotKey = selectedDate.replace("/", "-")
        val timeKey = timeSlot.replace(":", "-").replace(" ", "_")

        val ref = FirebaseDatabase.getInstance(DB_URL).getReference("SlotCount").child(slotKey).child(timeKey)
        ref.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                currentSlotOccupancy = snapshot.getValue(Int::class.java) ?: 0
                validateFinalSelection()
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun validateFinalSelection() {
        val guestsText = etGuests.text.toString().trim()
        val guests = guestsText.toIntOrNull() ?: 0
        val available = CAFE_MAX_CAPACITY - currentSlotOccupancy

        val isWithinLimit = guests in 1..MAX_GUESTS_PER_BOOKING
        val isWithinCapacity = guests <= available

        if (selectedDate.isNotEmpty() && spinnerTimeSlots.selectedItemPosition > 0 && isWithinLimit && isWithinCapacity) {
            btnConfirmBooking.isEnabled = true
            btnConfirmBooking.alpha = 1.0f
            etGuests.error = null
        } else {
            btnConfirmBooking.isEnabled = false
            btnConfirmBooking.alpha = 0.5f
            if (guestsText.isNotEmpty()) {
                if (guests > available) etGuests.error = "Only $available slots left!"
                else if (guests > MAX_GUESTS_PER_BOOKING) etGuests.error = "Max 20 per booking"
            }
        }
    }

    private fun attemptBooking() {
        val guestsText = etGuests.text.toString().trim()
        val guests = guestsText.toIntOrNull() ?: return
        val rawSelected = spinnerTimeSlots.selectedItem.toString()
        val timeSlot = rawSelected.split(" (")[0]
        val userId = auth.currentUser?.uid ?: return

        progressBar.visibility = View.VISIBLE
        btnConfirmBooking.isEnabled = false

        val bookingsRef = FirebaseDatabase.getInstance(DB_URL).getReference("Bookings")
        bookingsRef.orderByChild("userId").equalTo(userId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var hasExisting = false
                for (snap in snapshot.children) {
                    if (snap.child("date").getValue(String::class.java) == selectedDate &&
                        snap.child("timeSlot").getValue(String::class.java) == timeSlot &&
                        snap.child("status").getValue(String::class.java) == "Confirmed") {
                        hasExisting = true
                        break
                    }
                }

                if (hasExisting) {
                    progressBar.visibility = View.GONE
                    btnConfirmBooking.isEnabled = true
                    AlertDialog.Builder(this@BookingActivity)
                        .setTitle("Duplicate")
                        .setMessage("You already have a booking for this slot. Cancel it first.")
                        .setPositiveButton("OK", null).show()
                } else {
                    performTransaction(userId, timeSlot, guests)
                }
            }
            override fun onCancelled(error: DatabaseError) { progressBar.visibility = View.GONE }
        })
    }

    private fun performTransaction(userId: String, timeSlot: String, guests: Int) {
        val slotKey = selectedDate.replace("/", "-")
        val timeKey = timeSlot.replace(":", "-").replace(" ", "_")
        val slotRef = FirebaseDatabase.getInstance(DB_URL).getReference("SlotCount").child(slotKey).child(timeKey)

        slotRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): Transaction.Result {
                val current = mutableData.getValue(Int::class.java) ?: 0
                if (current + guests > CAFE_MAX_CAPACITY) return Transaction.abort()
                mutableData.value = current + guests
                return Transaction.success(mutableData)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (committed) saveBookingToDb(userId, timeSlot, guests)
                else {
                    progressBar.visibility = View.GONE
                    btnConfirmBooking.isEnabled = true
                    Toast.makeText(this@BookingActivity, "Capacity full!", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun saveBookingToDb(userId: String, timeSlot: String, guests: Int) {
        val database = FirebaseDatabase.getInstance(DB_URL).getReference("Bookings")
        val bookingId = database.push().key ?: ""
        val booking = Booking(
            bookingId = bookingId, userId = userId, userName = userName, userPhone = userPhone,
            date = selectedDate, timeSlot = timeSlot, guests = guests, status = "Confirmed", timestamp = System.currentTimeMillis()
        )
        database.child(bookingId).setValue(booking).addOnSuccessListener {
            progressBar.visibility = View.GONE
            showBookingNotification(selectedDate, timeSlot)
            Toast.makeText(this, "Booking Successful!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun fetchUserInfo() {
        val uid = auth.currentUser?.uid ?: return
        FirebaseDatabase.getInstance(DB_URL).getReference("Users").child(uid)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    userName = snapshot.child("name").getValue(String::class.java) ?: ""
                    userPhone = snapshot.child("phone").getValue(String::class.java) ?: ""
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Booking Notify", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun showBookingNotification(date: String, time: String) {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Booking Confirmed!")
            .setContentText("Your visit on $date at $time is successful.")
            .setAutoCancel(true)
        try { NotificationManagerCompat.from(this).notify(1, builder.build()) } catch (e: SecurityException) {}
    }
}